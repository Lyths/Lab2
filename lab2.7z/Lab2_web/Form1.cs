using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Windows.Forms;
using static Lab2_web.Controllers.ServerController;

namespace Lab2_web
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var rsa = RSA.Create();
            var messageBytes = Encoding.UTF8.GetBytes(textBox1.Text);
            var signature = Convert.ToBase64String(rsa.SignData(messageBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pss));
            var publicKey = Convert.ToBase64String(rsa.ExportSubjectPublicKeyInfo());

            label2.Text = textBox1.Text;
            label4.Text = signature;
            label6.Text = publicKey;

            SetContextMenuLabel1();
            SetContextMenuLabel2();
            SetContextMenuLabel3();
        }

        private void SetContextMenuLabel1()
        {
            ContextMenuStrip contextMenu = new ContextMenuStrip();

            ToolStripMenuItem copyMenuItem = new ToolStripMenuItem("����������");
            copyMenuItem.DoubleClick += (sender, e) =>
            {
                Clipboard.SetText(label1.Text);
            };
            contextMenu.Items.Add(copyMenuItem);

            label1.ContextMenuStrip = contextMenu;
        }

        private void SetContextMenuLabel2()
        {
            ContextMenuStrip contextMenu = new ContextMenuStrip();

            ToolStripMenuItem copyMenuItem = new ToolStripMenuItem("����������");
            copyMenuItem.Click += (sender, e) =>
            {
                Clipboard.SetText(label2.Text);
            };
            contextMenu.Items.Add(copyMenuItem);

            label2.ContextMenuStrip = contextMenu;
        }

        private void SetContextMenuLabel3()
        {
            ContextMenuStrip contextMenu = new ContextMenuStrip();

            ToolStripMenuItem copyMenuItem = new ToolStripMenuItem("����������");
            copyMenuItem.Click += (sender, e) =>
            {
                Clipboard.SetText(label3.Text);
            };
            contextMenu.Items.Add(copyMenuItem);

            label3.ContextMenuStrip = contextMenu;
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            var result = await Validate();
            MessageBox.Show(result);
        }

        private async Task<string> Validate()
        {
            var message = new ClienTMessage
            {
                Message = textBox2.Text,
                Signature = textBox3.Text,
                PublicKey = textBox4.Text
            };

            HttpClient httpClient = new HttpClient();
            var result = await httpClient.PostAsJsonAsync("http://localhost:5119/Server/Verify", message);

            return await result.Content.ReadAsStringAsync();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var rsa = RSA.Create();
            rsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(textBox5.Text), out _);

            var data = Encoding.UTF8.GetBytes(textBox7.Text);
            var isSuccess = rsa.VerifyData(data, Convert.FromBase64String(textBox6.Text), HashAlgorithmName.SHA256, RSASignaturePadding.Pss);

            MessageBox.Show(isSuccess ? "������� �����" : "������� ���������������");
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            HttpClient httpClient = new HttpClient();
            var result = await httpClient.GetFromJsonAsync<ServerMessage>("http://localhost:5119/Server/GenerateSignedMessage");

            label2.Text = result.Message;
            label4.Text = result.Signature;
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            HttpClient httpClient = new HttpClient();
            var key = await (await httpClient.GetAsync("http://localhost:5119/Server/GetPublicKey")).Content.ReadAsStringAsync();

            label6.Text = key;
        }

        class ServerMessage
        {
            public string Message { get; set; }
            public string Signature { get; set; }
        };
    }
}
