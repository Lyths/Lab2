using Lab2_api;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using System.Text;

namespace Lab2_web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ServerController : ControllerBase
    {
        private readonly RsaService _rsaService;

        public ServerController(RsaService rsaService)
        {
            _rsaService = rsaService;
        }

        [HttpPost("CreateClientMessage")]
        public IActionResult CreateClientMessage(string message)
        {
            if(string.IsNullOrWhiteSpace(message))
                return BadRequest("��������� �� ����� ���� ������.");

            var rsa = RSA.Create();
            var messageBytes = Encoding.UTF8.GetBytes(message);
            var signature = rsa.SignData(messageBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
            var clientPublicKey = Convert.ToBase64String(rsa.ExportSubjectPublicKeyInfo());

            return Ok(new
            {
                Message = message,
                Signature = Convert.ToBase64String(signature),
                PublicKey = clientPublicKey
            });
        }

        [HttpPost("Verify")]
        public IActionResult Verify([FromBody] ClienTMessage dto)
        {
            var signatureBytes = Convert.FromBase64String(dto.Signature);
            var isValid = _rsaService.Verify(dto.Message, signatureBytes, dto.PublicKey);

            return Ok(isValid ? "������� �����" : "������� ���������������");
        }

        [HttpGet("GetPublicKey")]
        public IActionResult GetPublicKey()
        {
            return Ok(_rsaService.GetPublicKey());
        }

        [HttpGet("GenerateSignedMessage")]
        public IActionResult GenerateSignedMessage()
        {
            var message = $"Test_Message:{DateTime.UtcNow}";
            var signature = _rsaService.SignData(message);

            return Ok(new
            {
                Message = message,
                Signature = Convert.ToBase64String(signature)
            });
        }

        public class ClienTMessage
        {
            public string Message { get; set; }
            public string Signature { get; set; }
            public string PublicKey { get; set; }
        }
    }
}
