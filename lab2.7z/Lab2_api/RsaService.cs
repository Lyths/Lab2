﻿using System.Security.Cryptography;
using System.Text;

namespace Lab2_api
{
    public class RsaService
    {
        private RSA _rsa;
        public RsaService()
        {
            _rsa = RSA.Create();
        }

        public string GetPublicKey()
            => Convert.ToBase64String(_rsa.ExportSubjectPublicKeyInfo());

        public byte[] SignData(string message)
        {
            var data = Encoding.UTF8.GetBytes(message);
            return _rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
        }

        public bool Verify(string message, byte[] signature, string publicKey)
        {
            var rsa = RSA.Create();
            rsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(publicKey), out _);

            var data = Encoding.UTF8.GetBytes(message);
            return rsa.VerifyData(data, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
        }
    }
}
